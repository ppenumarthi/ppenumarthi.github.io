%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%        K-user IC simulation       %
%     Dimitris S. Papailiopoulos    %
%            March 2011             %
% University of Southern California %
%             ver 1.0               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
clear all
close all

cvx_quiet(true) % make cvx silent

MC = 1; % #Monte Carlo Simulations
K = 3; % number of users
dk = 2; % requested DoF/user
Mt = 2; % #Tx antennas
Mr = 2; % #Rx antennas
iter_nucnorm = 5; % #iterations of nuclear approximation
iter_leakmin = 1000; % #iterations of leakage minimization
iter_maxsinr = 1000; % #iterations of max-SINR
epsilon = 0.1; % the epsilon parameter of our approximation
Pdb = [0:20:20]; % transmit power in dB
DoF_accuracy = 10^-6; % the DoF is calculated by counting singular values that have value larger than DoF_accuracy

d_start = 1; % select from which DoF/user we wish to begin

display([num2str(K),'-user Interference Channel Mr = ', num2str(Mr),', Mt = ',num2str(Mt) '.'])
display(' ');
for d = d_start:dk
    for p = 1:length(Pdb)
        display(['Running ',num2str(MC), ' Monte Carlo simulations for power = ', num2str(Pdb(p)) ,'dB, and requested DoF/user = ',num2str(d)])
        P_stream = 10^(Pdb(p)/10)/(1*d); % convert from log to linear
        
        for i = 1:MC
            H = randn(Mr,Mt,K,K);   % generate gaussian i.i.d channels
            U_rand = normalize(randn(Mr,d,K)); % randomly draw zeroforcing matrices of norm 1
            V_rand = normalize(randn(Mt,d,K)); % randomly draw beamforming matrices of norm 1
            
            %%%%%%%%%%%%%%%%%% nuclear norm %%%%%%%%%%%%%%%%%%
            clear V_l1 U_l1 V_l2 U_l2 V_sinr U_sinr V_sinr_qr U_sinr_qr S_eig J_eig
            
            tic
            [V_l1 U_l1] = nuclear_IA_K_user(H, orthogonalize(U_rand), epsilon, iter_nucnorm, 0);
            display(['Nuclear norm algorithm, MC ',num2str(i),':'])
            toc
            
            V_l1 = orthogonalize(V_l1); % make beamformers orthonormal
            U_l1 = orthogonalize(U_l1); % make zeroforcers orthonormal
            [S_eig J_eig] = block_svd(U_l1, H, V_l1); % find useful and interference eigenvalues
            DoF_l1(i,p,d) = max(mean(sum(S_eig>DoF_accuracy,1) - sum(J_eig>DoF_accuracy,1)),0); % calculate DoF
            V_l1 = sqrt(P_stream)*V_l1; % amplify transmit beamformers
            R_l1(i,p,d)    = rate_K_user_MIMO(U_l1, H, V_l1); % calculate sum rate
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %%%%%%%%%%%%%%% leakage minimization %%%%%%%%%%%%%
            clear V_l1 U_l1 V_l2 U_l2 V_sinr U_sinr V_sinr_qr U_sinr_qr S_eig J_eig
            
            tic
            [V_l2, U_l2] = leakage_minimization_K_user(H, orthogonalize(V_rand), iter_leakmin); % run leakage minimization
            display(['Leakage minimization algorithm, MC ',num2str(i),':'])
            toc
            
            V_l2 = normalize(V_l2); % normalize beamformers
            U_l2 = normalize(U_l2); % normalize zeroforcers
            [S_eig J_eig] = block_svd(U_l2, H, V_l2); % find useful and interference eigenvalues
            DoF_l2(i,p,d) = max(mean(sum(S_eig>DoF_accuracy,1) - sum(J_eig>DoF_accuracy,1)),0); % calculate DoF
            V_l2 = sqrt(P_stream)*V_l2; % amplify transmit beamformers
            R_l2(i,p,d)    = rate_K_user_MIMO(U_l2, H, V_l2);% calculate sum rate
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%% max-SINR %%%%%%%%%%%%%%%%%%%
            clear V_l1 U_l1 V_l2 U_l2 V_sinr U_sinr V_sinr_qr U_sinr_qr S_eig J_eig
            
            tic
            [V_sinr, U_sinr] = maxSINR_K_user(H, V_rand, P_stream, iter_maxsinr); % run max-SINR approach
            display(['Max-SINR algorithm, MC ',num2str(i),':'])
            toc
            
            %%%%%% compute normalized max-SINR matrices %%%%%%
            V_sinr = normalize(V_sinr); % normalize beamformaers
            U_sinr = normalize(U_sinr); % normalize zeroforcers
            [S_eig J_eig] = block_svd(U_sinr, H, V_sinr); % find useful and interference eigenvalues
            DoF_sinr(i,p,d) = max(mean(sum(S_eig>DoF_accuracy,1) - sum(J_eig>DoF_accuracy,1)),0); % calculate DoF
            V_sinr = sqrt(P_stream)*V_sinr; % amplify transmit beamformers
            R_sinr(i,p,d)    = rate_K_user_MIMO(U_sinr, H, V_sinr);% calculate sum rate
            %%%% compute orthogonalized max-SINR matrices %%%%
            V_sinr_qr = orthogonalize(V_sinr); % orthogonalize beamformers
            U_sinr_qr = orthogonalize(U_sinr); % orthogonalize zeroforcers
            DoF_sinr_qr(i,p,d) = max(mean(sum(S_eig>DoF_accuracy,1) - sum(J_eig>DoF_accuracy,1)),0); % calculate DoF
            V_sinr_qr = sqrt(P_stream)*V_sinr_qr; % amplify transmit beamformers
            R_sinr_qr(i,p,d)    = rate_K_user_MIMO(U_sinr_qr, H, V_sinr_qr); % calculate sum rate
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        end
        display(' ')
    end
end
