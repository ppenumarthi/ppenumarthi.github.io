% block_svd(U, H, V) returns two 3-D matrix matrices S_eig and J_eig.
% S_eig(:,:,k) and J_eig(:,:,k)  hold the singular values of the useful and
% interference spaces, respectively, of user k.
% The inputs are the K zeroforcers U, the K^2 MrxMt channels H, and the K
% beamformers V.

function [S_eig, J_eig] = block_svd(U, H, V)

[~, dk, K] = size(V); % obtain problem parameters

S = zeros(dk,dk,K); % initialize the useful signal matrix
S_eig = zeros(dk, K);
J = zeros(dk, (K-1)*dk, K); % initialize the interference matrix
J_eig = zeros(dk, K);
for k = 1:K
    %%% construct interference matrix %%%
    for l = [1:k-1 k+1:K]
        J(:,(l-1)*dk+1:l*dk,k) = U(:,:,k)'*H(:,:,k,l)*V(:,:,l); %each term is one interference block
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    S(:,:,k) = U(:,:,k)'*H(:,:,k,k)*V(:,:,k); % construct the signal space matrix
    
    S_eig(:,k) = svd(S(:,:,k)); % obtain the usefeul space singular values
    J_eig(:,k) = svd(J(:,:,k)); % obtain the interference space singular values
end

end
