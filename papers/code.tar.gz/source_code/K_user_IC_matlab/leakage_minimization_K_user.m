% leakage_minimization_K_user(H, V, iter) runs the leakage minimization 
% algorithm and returns the set of K beamforming V and the set of K zeroforcing U matrices. 
% The inputs are the K^2 MrxMt channels H, the K initialization beamformers V, and the number of iterations.

function [V, U] = leakage_minimization_K_user(H, V, iter)

[Mr, Mt, K, ~] = size(H); % obtain problem parameters
dk = size(V,2);
U = zeros(Mr, dk, K);

for i = 1:iter
    clear U Qv U_eig % clear values used in the following
    Qv = zeros(Mr, (K-1)*dk, K); % initialize the interference covariance
    for k = 1:K
        for l = [1:k-1 k+1:K] % you get interference from all l\ne k users
             Qv(:,(l-1)*dk+1:l*dk,k) = H(:,:,k,l)*V(:,:,l); % build the interference covariance (no need to multiply with P_stream)
        end
        for kk = 1:K
            [U_eig, ~] = eig(Qv(:,:,k)*Qv(:,:,k)'); % compute zeroforcers
            U(:,:,k) = U_eig(:,1:dk);
        end
        
    end
    clear V Qu V_eig % clear values used in the following
    Qu = zeros(Mt, (K-1)*dk, K); % initialize reciprocal interference covariance
    for k = 1:K
        for l = [1:k-1 k+1:K]
            Qu(:,(l-1)*dk+1:l*dk,k) = H(:,:,l,k)'*U(:,:,l); % build reciprocal interference covariance (no need to multiply with P_stream)
        end
        for kk = 1:K
            [V_eig, ~] = eig(Qu(:,:,k)*Qu(:,:,k)'); % compute beamformers
            V(:,:,k) = V_eig(:,1:dk);
        end
    end
end

end

