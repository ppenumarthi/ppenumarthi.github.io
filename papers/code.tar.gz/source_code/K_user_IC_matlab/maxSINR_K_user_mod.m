% maxSINR_V(H, V, P_stream, iter) runs the max-SINR algorithm and returns 
% the set of beamforming and zeroforcing matrices V and U. 
% The inputs are the K^2 MrxMt channels H, the K initialization 
% beamformers V, the power allocated per user's stream P_stream, and the number of iterations.

%--------------------------------------------------------
% Phani Comments Start here
%
%     The implementation given by them is based on iterations... however, I want result based on convergence. Hence, the last paramter will be \delta, the tolerable difference of IA vectors for adjacent iterations.
%
% Phani Comments End here
%--------------------------------------------------------
function [V, U] = maxSINR_K_user_mod(H, V, P_stream, iter)

[Mr, Mt, K, ~] = size(H); % obtain problem parameters
dk = size(V,2);
U = zeros(Mr, dk, K);
U_old = zeros(Mr, dk, K);
V_old= V;
j_u = 0; j_v = 0;
%accuracy = delta;
%--------------------------------------------------------
for i = 1:iter
    for k = 1:K
        for l = 1:dk
        if i == 1        
      	U_old(:,l,k) =0.0;
      	end
            B_kl = 0; % initialize interference plus noise covariance matrix
            % compute the interference plus noise covariance matrix
            for j = 1:K
                for d_i = 1:dk
                    B_kl = B_kl + P_stream*H(:,:,k,j)*V(:,d_i,j)*V(:,d_i,j)'*H(:,:,k,j)';
                end
                B_kl = B_kl - P_stream*H(:,:,k,k)*V(:,l,k)*V(:,l,k)'*H(:,:,k,k)';  %Compute Interference due to each antenna and multiply the signal along with noise -- Phani
            end
            B_kl = B_kl+eye(Mr); %Make this error into a Identity Matrix at the receiver with M_r rows and columns
            %%%
            B_kl_inv = B_kl^-1;
            U(:,l,k) = B_kl_inv*H(:,:,k,k)*V(:,l,k)./ norm(B_kl_inv*H(:,:,k,k)*V(:,l,k)); % compute the l-th column of the k-th zeroforcer
        end
    end
%--------------------------------------------------------
%Additions by Phani starts here
%   if j_u ~= 1-------------removed after checking properly that j_u and j_v should be populated every moment of time, and can vary in next iterations
	    for k = 1:K
		for l = 1:dk
		    if(U(:,l,k) - U_old(:,l,k) <= 0.0001)
		     j_u=1;
		    else
		     j_u=0;
		     break
		    end 
		end
	    end    
%   end
%Additions by Phani ends here    
%--------------------------------------------------------
    for k = 1:K
        for l = 1:dk
            B_kl = 0; % initialize reciprocal interference plus noise covariance matrix
            % compute the reciprocal interference plus noise covariance matrix
            for j = 1:K
                for d_i = 1:dk
                    B_kl = B_kl + P_stream*H(:,:,j,k)'*U(:,d_i,j)*U(:,d_i,j)'*H(:,:,j,k);
                end
                B_kl = B_kl - P_stream*H(:,:,k,k)'*U(:,l,k)*U(:,l,k)'*H(:,:,k,k);
            end
            %%%
            B_kl = B_kl+eye(Mt);
            B_kl_inv = B_kl^-1;
            V(:,l,k) = B_kl_inv*H(:,:,k,k)'*U(:,l,k)./ norm(B_kl_inv*H(:,:,k,k)'*U(:,l,k)); % compute the l-th column the k-th beamformer
        end
    end   
%--------------------------------------------------------
%Additions by Phani starts here    
%    if j_v ~= 1  -------------removed after checking properly that j_u and j_v should be populated every moment of time, and can vary in next iterations
	    for k = 1:K
		for l = 1:dk
		    if(V(:,l,k) - V_old(:,l,k) <= 0.0001)
		     j_v=1;
		    else
		     j_v=0;
		     break
		    end 
		end
	    end    
%    end
%--------------------------------------------------------

%Added for debgging --- to be removed
%   display('V_sinr U_sinr are' ); 
%   for k = 1:K
%        for l = 1:dk    
%    		display(['for k= ',num2str(k),' values are',num2str(V(1,l,k)),'	',num2str(V(2,l,k)),'.		',num2str(U(1,l,k)),'	',num2str(U(2,l,k)), '.']);
%        end
%        display('\n');
%   end
%--------------------------------------------------------
   if (j_u == 1 && j_v == 1)
    display (['Finished at our proposed end with values of j_u and j_v are',num2str(j_u),'and ',num2str(j_v), 'after ',num2str(iter),'Number of iterations']);
    break;
   end
%Additions by Phani ends here       
   U_old = U;
   V_old = V;
end
%display('U_sinr ' ,num2str(U_sinr),'and V_sinr in maxSINR_K_User1 are ',num2str(V_sinr) );
%display('U_sinr V_sinr are' );
%display(U_sinr);
end
