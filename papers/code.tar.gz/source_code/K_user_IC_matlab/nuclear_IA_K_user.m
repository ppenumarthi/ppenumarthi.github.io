% nuclear_IA_K_user(H, U, epsilon, iter) runs the nuclear norm heuristic 
% and returns the set of K beamforming and the set of K zeroforcing matrices V and U.  
% The inputs are the K^2 MrxMt channels H, the K initialization zeroforcers U, the epsilon constant, and the number of iterations. 

function [V U] = nuclear_IA_K_user(H, U, epsilon, iter, cell)

[Mr, Mt, K, ~] = size(H); % obtain problem parameters
dk = size(U,2);

for i = 1:2*iter % 2 turns at each iteration
        
    cvx_begin
    if mod(i,2) == 1 % at odd turns, we optimze over the beamformers
        clear V J f_cost A
        variable V(Mt,dk,K) 
    elseif mod(i,2) == 0 % at even turns, we optimze over the zeroforcers
        clear U J f_cost A
        variable U(Mr,dk,K)
    end
    %%% the following defines the cost function %%%
    J = cvx(zeros(dk, (K-1)*dk, K)); %initialize the interference matrix
    f_cost = cvx(0); % initialize cost function
    for k = 1:K
        for l = [1:k-1 k+1:K]
            J(:,(l-1)*dk+1:l*dk,k) = U(:,:,k)'*H(:,:,k,l)*V(:,:,l); %each term is one interference block
        end
        f_cost = f_cost+norm_nuc(J(:,:,k)); % the cost function is the sum of interference singular values
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%% nuclear norm minimization %%%%%%%%%%%
    minimize f_cost
    subject to
    for k = 1:K
        U(:,:,k)'*H(:,:,k,k)*V(:,:,k) == semidefinite(dk) 
        lambda_min(full(U(:,:,k)'*H(:,:,k,k)*V(:,:,k))) >= epsilon % minimum eigenvalue constraint
        % nonnegative definite constraint 
        % (not needed, cvx automatically sets S_k to NND due to the lambda_min constraint)
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%% the following adds the constraints for the cellular case %%%
    if cell==1
        for k = 1:K
            V(Mt/dk+1:end,1,k)==0;
            V(1:end-Mt/dk,dk,k)==0;
        end
        for n = 1:dk-2
            for k = 1:K
                V([1:n*Mt/dk (n+1)*Mt/dk+1:end],n+1,k)==0;
            end
        end        
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    cvx_end
    
end

end



