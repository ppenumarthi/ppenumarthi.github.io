% orthogonalize(X) runs a QR decomposition on a 3-D matrix. 
% It performs the QR decomposition for all matrices along the 3rd dimension.
% The input is the 3-D matrix X.

function  Qlite = orthogonalize(X)

% Q = zeros(size(X));
for i = 1:size(X,3)
    [Q(:,:,i) R] = qr(X(:,:,i)); % perform QR decomposition on X(:,:,i)
    r = rank(R); % find the rank of X(:,:,i)
    Qlite(:,:,i)=[Q(:,1:r,i) zeros(size(X,1),size(X,2)-r)]; % keep only the r columns of Q(:,:,i), that span the columnspace of X(:,:,i)
end

end

