% rate_K_user_MIMO(U, H, V, P_stream) computes the data rate of a real K-user IC. 
% The inputs are the K zeroforcers U, the K^2 MrxMt channels H, and the K
% beamformers V.

function R = rate_K_user_MIMO(U, H, V)

R = 0;
[~, dk K] = size(V); % obtain the parameters
S = zeros(dk,dk,K); % initialize the useful signal matrix
J = zeros(dk, (K-1)*dk, K); % initialize the interference matrix
for k = 1:K
    %%% construct interference matrix %%%
    for l = [1:k-1 k+1:K]
        J(:,(l-1)*dk+1:l*dk,k) = U(:,:,k)'*H(:,:,k,l)*V(:,:,l); %each term is one interference block
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    S(:,:,k) = U(:,:,k)'*H(:,:,k,k)*V(:,:,k); % construct the signal space matrix    
    R = R + 0.5*log2(det(eye(size(J,1))+(eye(size(J,1))+J(:,:,k)*J(:,:,k)')^-1*S(:,:,k)*S(:,:,k)')); % calculate the rate
end

end

