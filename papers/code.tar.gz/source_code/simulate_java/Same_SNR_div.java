package simulate;

import java.util.Random;

import simulate.Complex;

public class Same_SNR_div {

	/**
	 * @param args
	 */
	public static int num_MS = 4;
	public static int num_antenna_each_MS = 2;
	public static int num_antenna_MS = num_antenna_each_MS * num_MS; 
	public static int num_antenna_BS = num_antenna_MS;
	public static double beta_ICI = 0;
	public static int count = 10000;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Number of MS\tNumber of Antenna at each MS\tICI\tSIR\t\t\tSTDEV of SIR");
		
		beta_ICI = 0;
		num_antenna_each_MS = 1;
		
		for(int i=1; i<20; i++){
			num_MS = i;
			num_antenna_BS= num_antenna_each_MS * num_MS; 
			num_antenna_MS = num_antenna_each_MS * num_MS; 
			run_one();
		}
		
		num_antenna_each_MS = 2;
		for(int i=1; i<20; i++){
			num_MS = i;
			num_antenna_BS= num_antenna_each_MS * num_MS; 
			num_antenna_MS = num_antenna_each_MS * num_MS; 
			run_one();
		}
		
		beta_ICI = 0.1;
		num_antenna_each_MS = 1;
		
		for(int i=1; i<20; i++){
			num_MS = i;
			num_antenna_BS= num_antenna_each_MS * num_MS; 
			num_antenna_MS = num_antenna_each_MS * num_MS; 
			run_one();
		}
		
		num_antenna_each_MS = 2;
		for(int i=1; i<20; i++){
			num_MS = i;
			num_antenna_BS= num_antenna_each_MS * num_MS; 
			num_antenna_MS = num_antenna_each_MS * num_MS; 
			run_one();
		}
	}

	
	
	public static void run_one() {
		double sir_value[] = new double[count];
		for(int i=0; i<count; i++){
			sir_value[i]=once(i);
		}
		double sir_mean=mean(sir_value,count);
		double sir_std=stdev(sir_value,count,sir_mean);
		
		System.out.println(num_MS+"\t\t"+num_antenna_each_MS+"\t\t\t\t"+beta_ICI+"\t"+sir_mean+"\t"+sir_std);
		
	}
	
	public static double once(int seed){
		Complex H[][][] = new Complex[3][num_antenna_BS][num_antenna_MS]; // 3 is corresponding to neighbouring sub-carriers
		Complex N[] = new Complex[num_antenna_BS];
		
		Random rnoise;
		rnoise=new Random(seed);
		
		for( int i=0; i<num_antenna_BS ; i++){
			N[i] = new Complex(Math.abs(rnoise.nextGaussian()%0.1),Math.abs(rnoise.nextGaussian()%0.1));
		}
		
		H= prepare(H);
		
//		print(H);
		
		double sir[] = new double[num_antenna_BS];
		sir = compute_SIR(H,N);
		
//		print(sir,num_antenna_BS);
		
		return(get_SIR(sir));
	}
	
	
	private static double get_SIR(double[] sir) {
		// TODO Auto-generated method stub
			double avg_sir=0;
			for (int i=0; i< num_antenna_BS; i++){
				avg_sir+=sir[i];
			}
			avg_sir/=num_antenna_BS;
			return avg_sir;		
	}
	
	private static double stdev(double[] sirValue, int count2, double mean) {
	
		// TODO Auto-generated method stub
		double stdev=0;
		for(int i=0;i<count2;i++){
			stdev=Math.pow((sirValue[i]-mean), 2);
		}
		stdev/=count2;
		stdev=Math.sqrt(stdev);
		return stdev;
	}

	private static double mean(double[] sirValue, int count2) {
		// TODO Auto-generated method stub
		double mean=0;
		for(int i=0;i<count2; i++){
			mean+=sirValue[i];
		}
		mean/=count2;
		return mean;
	}
	
	
	private static void print(double[] sir, int numAntennaBS) {
		// TODO Auto-generated method stub
		for(int i=0;i<numAntennaBS; i++){
			System.out.println(sir[i]);
		}
	}


	public static Complex[][][] prepare(Complex[][][] h) {
		// TODO Auto-generated method stub
		Random r;
		r=new Random(System.currentTimeMillis());
		
		if(num_antenna_each_MS == 2){
			for(int ms=0;ms<num_MS;ms++){
//				float hi=r.nextFloat();
				for (int k=0; k<3; k++){
					for(int j=0;j<num_antenna_MS;j++){
						if(j == ms*2 ){		// In case of using Diversity technique for transmission
//							System.out.println("entered"+j+"with hi as"+hi);
							h[k][ms*2][ms*2]=new Complex(  (1+r.nextGaussian()%0.1) ,  (1+r.nextGaussian()%0.1) );
							h[k][ms*2][ms*2+1]=new Complex(  (1+r.nextGaussian()%0.1),   (1+r.nextGaussian()%0.1)  );
							h[k][ms*2+1][ms*2+1]=new Complex( (1+r.nextGaussian()%0.1),  (1+r.nextGaussian()%0.1) );	j++;
							h[k][ms*2+1][ms*2]=new Complex(  (1+r.nextGaussian()%0.1), (1+r.nextGaussian()%0.1)  );
						}
						else{
							h[k][ms*2][j]=new Complex(  Math.abs(r.nextGaussian()%0.25)  ,   Math.abs(r.nextGaussian()%0.25)  );
							h[k][ms*2+1][j]=new Complex(  Math.abs(r.nextGaussian()%0.25)  ,   Math.abs(r.nextGaussian()%0.25)  );
						}
					}
				}
			}
		}
		else{
			for (int i=0; i<num_antenna_BS; i++){
				for (int k=0; k<3; k++){		
//					float hi=r.nextFloat(); 
					for (int j=0; j< num_antenna_MS; j++){
						if (i != j)
							h[k][i][j]=new Complex(  Math.abs(r.nextGaussian()%0.25)  ,  Math.abs(r.nextGaussian()%0.25)  );
						else
							h[k][i][j]=new Complex(  (1+r.nextGaussian()%0.1)  ,  (1+r.nextGaussian()%0.1)  );
					}
				}
			}
		}
	
		return h;
	}
	
	private static double[] compute_SIR(Complex[][][] h, Complex[] n) {
		// TODO Auto-generated method stub
//		We calculate SINR only for sub-carrier 1 such that we include ICI due to both 0 and 2 sub-carriers.  It can be calculated similarly for other sub-carriers also.
		double sir[] = new double[num_antenna_BS];
		double sir_temp[] = new double[num_antenna_BS];
		double interference[] = new double[num_antenna_BS];
		int i=0;
		
		if(num_antenna_each_MS == 2){
			for ( ; i<num_antenna_BS ; i++){
				sir_temp[i]=0;
				interference[i]=0;
				for ( int j=0; j<num_antenna_MS ; j++){
					
//					if (j==i || (j%2 == 0 && j== (i+1)) || (j%2 != 0 && j== (i-1)) ){	// For Diversity
					if (j==i ){	// Multiplexing
						sir_temp[i] = h[1][i][j].mod() * h[1][i][j].mod();							
						//For Diversity
						if(j%2 == 0)
							sir_temp[i] += h[1][i][j+1].mod() * h[1][i][j+1].mod();
						else
							sir_temp[i] += h[1][i][j-1].mod() * h[1][i][j-1].mod();
						j++;
					}	
					else {
//						System.out.println("i="+i+" and j="+j+"with values "+h[1][i][j]);
						interference[i]+= h[1][i][j].mod() * h[1][i][j].mod();   // Due to MIMO
						interference[i]+= beta_ICI * h[0][i][j].mod() * h[0][i][j].mod();   // Due to ICI and MIMO
						interference[i]+= beta_ICI * h[2][i][j].mod() * h[2][i][j].mod();   // Due to ICI and MIMO
					}
					
				}
				/* 
				 * Only due to Noise
				 * 		sir_temp[i]=h[1][i][i].mod() * h[1][i][i].mod();
				 *		interference[i]=n[i].mod() * n[i].mod();
				 *		System.out.println(sir_temp[i]+"   and  "+interference[i]);
				 */
				sir[i] = sir_temp[i]/interference[i];
			}
		}
		else {
			for ( ; i<num_antenna_BS ; i++){
				sir_temp[i]=0;
				interference[i]=0;
				for ( int j=0; j<num_antenna_MS ; j++){
					if (i==j){
						sir_temp[i] = h[1][i][j].mod() * h[1][i][j].mod();
//						Due to ICI
						interference[i] += beta_ICI * h[0][i][j].mod() * h[0][i][j].mod();
						interference[i] += beta_ICI * h[2][i][j].mod() * h[2][i][j].mod();
					}						//
					else {
						interference[i] += h[1][i][j].mod() * h[1][i][j].mod(); 			//	Due to MIMO
						interference[i] += beta_ICI * h[0][i][j].mod() * h[0][i][j].mod();	//	Due to ICI and MIMO
						interference[i] += beta_ICI * h[2][i][j].mod() * h[2][i][j].mod();	//	Due to ICI and MIMO						
					}				
				}
				sir[i] = sir_temp[i]/interference[i];			
			}
		}

//		for ( i=0; i<num_antenna_BS ; i++){
//			System.out.println("SIR_temp["+i+"] and INT["+i+"] are "+sir_temp[i]+"\t"+interference[i]);
//		}
		return sir;
	}
	
	private static void print(Complex[][][] h) {
		// TODO Auto-generated method stub
		System.out.println("Values of Channel coefficient Matrix are");
		for (int k=0;k<3;k++){
			System.out.println("For "+k+"th subcarrier");
			for (int i=0; i<num_antenna_BS; i++){
				for (int j=0; j< num_antenna_MS; j++){
					System.out.print(h[k][i][j].toString()+"\t");
				}
				System.out.println();
			}
		}
	}
}
