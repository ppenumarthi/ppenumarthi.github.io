#ifndef MUNKRES_H
#define	MUNKRES_H

#include <iostream>
#include <vector>

//struct for the cells of the matrix
struct cell
{
	//The weight value in the cell
	int weight;
	//Values for whether the cell is primed or starred
	bool starred, primed;
	
	//initialize starred and primed values to false
	cell()
	{
		starred = false;
		primed = false;
		weight = -1;
	}
};

//It's an ordered_pair, not much else to say
struct ordered_pair
{
	int row, col;
};

class munkres
{
public:
	munkres(void);
	~munkres(void);
	
	//turn diagnostics on or off
	void set_diag(bool a)
	{
		diag_on = a;
	}
	
	//assign a matching
	//returns the total weight of the matching
	//takes a pointer to integer as a parameter and this
	//will be the matching in the form of an array
	int assign(ordered_pair *matching);
	
	//Load weight array from a vector of vectors of integers
	//Accepts an object of type vector< vector<int> >, which is
	//a matrix of any dimensions with integer values > -1
	void load_weights(std::vector< std::vector<int> > x, int size);

private:

	//Delimiters to show number of operable rows and columns
	//after the cell array is populated
	int num_rows;
	int num_columns;

	//arrays to keep track of which columns and rows have 
	//starred zeroes
	std::vector<bool> row_starred, column_starred; 

	//array to show which rows and columns are covered
	std::vector<bool> row_cov, column_cov;
	
	//A boolean value to turn daignostics on or off
	bool diag_on;

	//Initialize all variables for operations
	void init(void);

	//The matrix operated on by Munkres' algorithm
	//(could be better than an array in the future)
	std::vector< std::vector<cell> > cell_array;

	//array to store the weights for calculating total weight
	std::vector< std::vector<int> > weight_array;

	//functions to check if there is a starred zero in the current row or column
	int find_star_column(int c);
	int find_star_row(int r);

	//functions to check if there is a primed zero in the current row or column
	int find_prime_column(int c);
	int find_prime_row(int r);

	//These are the declarations for Munkres' algorithm steps
	void step1(void);
	void step2(void);
	bool step3(void);
	bool step4(void);
	bool step5(int, int);
	bool step6(int sub);

	//The function that will call each of step of Munkres' algorithm in turn
	//We're using this since multiple functions use the algorithm
	bool find_a_matching(void);

	//A function simply for diagnostic purposes
	//Useful for testing new code and to help both myself and anyone who
	//wants to modify this in the future
	void diagnostic(int a) 	const;
};
#endif
